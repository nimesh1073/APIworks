import logo from './logo.svg';
import './App.css';
import {BrowserRouter,Routes,Route} from 'react-router-dom';
import Home from './Components/Home';
import Register from './Components/Register';
import Login from './Components/Login';
import View from './Components/View';
import Search from './Components/Search';
import Navbar from './Components/Navbar';
import Edit from './Components/Edit';
import Add from './Components/Add';
import Detail from './Components/Detail';


function App() {
  return (
    <div className="App">

      <BrowserRouter>
      <Navbar/>
      <Routes>
        <Route path="/" element={<Home/>}></Route>
        <Route path="/register" element={<Register/>}></Route>
        <Route path="/login" element={<Login/>}></Route>
        <Route path="/add" element={<Add/>}></Route>
        <Route path="/view" element={<View/>}></Route>
        <Route path="/search" element={<Search/>}></Route>
        <Route path="/edit" element={<Edit/>}></Route>
        <Route path="/detail" element={<Detail/>}></Route>
      </Routes>
      </BrowserRouter>
      
      
      
      
    </div>
  );
}

export default App;
