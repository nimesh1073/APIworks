import React, { useEffect, useState } from 'react'
import { useLocation } from 'react-router-dom'
import { getbookdetail } from '../Services/Apicall'

function Detail() {
  const [book,setbook]=useState({})

  const {search}=useLocation()
  // console.log(search)

  const queryParams=new URLSearchParams(search)

  const id=queryParams.get('id')

  async function fetchbooks(){
    let res=await getbookdetail(id)
    setbook(res.data)
    // console.log(res)
  }

  useEffect(()=>{fetchbooks()},[])

  console.log(id)
  return (
    <div>
      <h2 class="mt-4">Detail</h2>
      <div class="container mt-5 w-50 border bg-warning text-light shadow p-2">
      <table class="table table-bordered p-3">
        <thead>
        <tr>
          <th>Cover</th>
          <td><img src={book.image} height="150px" width="100px"></img></td>
        </tr>
        <tr>
          <th>Title</th>
            <td>{book.title}</td>
        </tr>
        <tr>
          <th>Author</th>
            <td>{book.author}</td>
        </tr>
        <tr>
          <th>Pages</th>
            <td>{book.pages}</td>
        </tr>
        <tr>
          <th>Price</th>
            <td>{book.price}</td>
        </tr>
        <tr>
          <th>Language</th>
            <td>{book.language}</td>
        </tr>

        </thead>
        
      </table>
      </div>
      
    </div>
  )
}

export default Detail