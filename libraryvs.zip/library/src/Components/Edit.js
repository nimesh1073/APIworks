import React, { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { editbookdetail, getbookdetail } from '../Services/Apicall'

function Edit() {

  const [book,setbook]=useState({'title':'','author':'','pages':'','price':'','language':'','image':null})

  const navigate=useNavigate()

  const {search}=useLocation()

  const queryParams=new URLSearchParams(search)

  const id=queryParams.get('id')

  async function fetchbookdetail(){
    let res=await getbookdetail(id)
    setbook(res.data)
  }

  async function editbook(event){
    event.preventDefault()

  const ubook={...book}

  if(typeof ubook.image=='string')
  {
    delete ubook.image
  }

  console.log(ubook)
  let res=await editbookdetail(ubook,id)
  console.log(book)
  navigate('/view')
  }

  useEffect(()=>{fetchbookdetail()},[])

  return (
    <div>
      <h2 class="mt-3">Edit Details</h2>
      <div class="container w-25 bg-warning shadow mt-3 border">
        <form onSubmit={editbook}>
        <div class="mb-3 mt-3">
          <label class="form-label">Title:</label>
          <input type="text" class="form-control" onChange={(event)=>{setbook({...book,'title':event.target.value})}} placeholder="Enter title" value={book.title}></input>
        </div>
        <div class="mb-3 mt-3">
          <label class="form-label">Author:</label>
          <input type="text" class="form-control" onChange={(event)=>{setbook({...book,'author':event.target.value})}} placeholder="Enter Author" value={book.author}></input>
        </div>
        <div class="mb-3 mt-3">
          <label class="form-label">Price:</label>
          <input type="text" class="form-control" onChange={(event)=>{setbook({...book,'price':event.target.value})}} placeholder="Enter Price" value={book.price}></input>
        </div>
        <div class="mb-3 mt-3">
          <label class="form-label">Language:</label>
          <input type="text" class="form-control" onChange={(event)=>{setbook({...book,'language':event.target.value})}} placeholder="Enter Language" value={book.language}></input>
        </div>
        <div class="mb-3 mt-3">
          <label class="form-label">Pages:</label>
          <input type="number" class="form-control" onChange={(event)=>{setbook({...book,'pages':event.target.value})}} placeholder="Enter Pages" value={book.pages}></input>
        </div>
          <div class="mb-3 mt-3">
          <label class="form-label">Image:</label>
          <img src={book.image} height="100px" width="80px"></img>
          <input type="file" class="form-control mt-3" onChange={(event)=>{setbook({...book,'image':event.target.files[0]})}}></input>
        </div>
        <div class="mb-3 mt-4">
          <input type="submit" class="btn btn-outline-secondary fw-bold"></input>
        </div>
        </form>
      </div>
    </div>
  )
}

export default Edit