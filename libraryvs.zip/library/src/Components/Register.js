import React, { useState } from 'react'
import { createuser } from '../Services/Apicall'
import { useNavigate } from 'react-router-dom'

function Register() {

  const [user,setuser]=useState({'username':'','password':'','email':'','first_name':'','last_name':''})

  const navigate=useNavigate()

  async function register(event){

    event.preventDefault()
    // console.log(user)

    let res=await createuser(user)
    console.log(res)
    navigate('/')
  }

  return (
    <div>
      <h2 class="mt-3">Register</h2>
      <div class="container w-50 mx-auto bg-warning p-2 mt-3 border shadow">
          <h2 class="text-center mt-3"></h2>
          <form onSubmit={register}>
          <div class="mb-3 mt-3">
            <label class="form-label">Username</label>
            <input type="text" class="form-control" onChange={(event)=>{setuser({...user,'username':event.target.value})}} placeholder="Enter Username"></input>
          </div>
          <div class="mb-3 mt-3">
            <label class="form-label">Password</label>
            <input type="password" class="form-control" onChange={(event)=>{setuser({...user,'password':event.target.value})}} placeholder="Enter Password"></input>
          </div>
            {/* <div class="mb-3 mt-3">
            <label class="form-label">Confirm Password</label>
            <input type="password" class="form-control" name="p1" placeholder="Re-Enter Password"></input>
          </div> */}
          <div class="mb-3 mt-3">
            <label class="form-label">Email</label>
            <input type="email" class="form-control" onChange={(event)=>{setuser({...user,'email':event.target.value})}} placeholder="Enter Email"></input>
          </div>
          <div class="mb-3 mt-3">
            <label class="form-label">First Name</label>
            <input type="text" class="form-control" onChange={(event)=>{setuser({...user,'first_name':event.target.value})}} placeholder="Enter First Name"></input>
          </div>
          <div class="mb-3 mt-3">
            <label class="form-label">Last Name</label>
            <input type="text" class="form-control" onChange={(event)=>{setuser({...user,'last_name':event.target.value})}} placeholder="Enter Last Name"></input>
          </div>
            {/* <div class="mb-3 mt-3">
            <label class="form-label">Phone Number</label>
            <input type="number" class="form-control" name="n" placeholder="Enter Phone Number"></input>
          </div>
            <div class="mb-3 mt-3">
            <label class="form-label">Address</label>
            <textarea class="form-control" name="a" placeholder="Enter Address"></textarea>
          </div> */}
          <div class="mb-3 mt-4">
            <input type="submit" class="btn btn-outline-light fw-bold"></input>
          </div>
          </form>
      </div>
    </div>
  )
}

export default Register