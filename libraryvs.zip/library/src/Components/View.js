import React, { useEffect, useState } from 'react'
import { deletebookdetail, getallbook } from '../Services/Apicall'
import { useNavigate } from 'react-router-dom'

function View() {
  const [book,setbook]=useState([])
  const navigate=useNavigate()

  function detail(i){
    // console.log(i)
    navigate(`/detail?id=${i}`)
  }

  async function deletebook(i){
    console.log(i)
    let res=await deletebookdetail(i)
    // console.log(res)
    if(res.status >199 && res.status<399)
    {
    fetchbooks()}
    else{
      alert("Cant delete book record.Try again...")
    }
  }

  async function editbook(i){
    // console.log(i)
    navigate (`/edit?id=${i}`)

  }

  async function fetchbooks(){
    let s=await getallbook()
    setbook(s.data)
  }

  useEffect(()=>{fetchbooks()},[])

  return (
    <div>
      <h2 class="text-center mt-5">BOOK DETAILS</h2>
      <div class="container mt-5 w-75 border bg-warning text-light shadow">
        <table class="table table-bordered mx-auto p-3 text-light">
          <thead>
            <tr>
              <th scope="col">Image</th>
              <th scope="col">Title</th>
              <th scope="col">Author</th>
              <th scope="col">Pages</th>
              <th scope="col">Price</th>
              <th scope="col">Language</th>
              <th scope="col">Actions</th>
            </tr>
          </thead>
          <tbody>
              {book.map((i)=><tr>
              <td><img src={i.image} height="100px"></img></td>
              <td>{i.title}</td>
              <td>{i.author}</td>
              <td>{i.pages}</td>
              <td>{i.price}</td>
              <td>{i.language}</td>
              <td><button class="btn btn-light me-2 mt-4" onClick={()=>detail(i.id)}>View</button><button class="btn btn-light me-2 mt-4" onClick={()=>editbook(i.id)}>Edit</button><button class="btn btn-light me-2 mt-4" onClick={()=>deletebook(i.id)}>Delete</button></td>
            </tr>)}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default View