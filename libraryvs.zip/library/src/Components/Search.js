import React from 'react'
import { useLocation } from 'react-router-dom'

function Search() {
  const {search}=useLocation()

  const queryParams=new URLSearchParams(search)

  const w=queryParams.get('word')

  console.log(w)

  return (
    <div>
      <h2>Search</h2>
    </div>
  )
}

export default Search